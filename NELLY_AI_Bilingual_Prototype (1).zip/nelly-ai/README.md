# NELLY — Personal AI

A redesigned visual prototype for NELLY, a bilingual English/Spanish personal AI.

## Run
Open `index.html` in a modern browser.

## Prototype status
This is the visual/interaction layer. The AI, streaming voice, image generation, web tools, files, and other capabilities are represented as UI modules and should be connected to the real backend in the next stage.
